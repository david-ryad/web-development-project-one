var sections=("Arrayfrom (document.querySelectorAll"("section"));
var menu= document.getElementById("navbar_list");
let numberofListItem = sections.length;
function createListItem(){
    for (section of sections);
}
sectionName= section.getAttribute ("data_nav");
sectionLink= section.getAttribute("id");
    listItem= document.createElement("li");
    listItem.innerHTML= <a class "menu_link"
    href="# ${sectionLink}"$ {sectionName}</a>
    menu.appendChild(listItem)
function sectionInViewPort(elem);
{
    let sectionPosition =elem.getBoundingClientRect()
    return (sectionpos.top >=1);
}
function toggleActiveClass()
{
 for (section of sections)
 {
     if (sectionInViewPort (section));
     if (!section.classList.contains("your-active-class"))
     {
       section.classList.add(your-active-class);   
     }
     else {section.classList.remove("your-active-class");}
     createListItem();
     document.addEventListener("scroll"toggleActiveClass);
    
 }   
}